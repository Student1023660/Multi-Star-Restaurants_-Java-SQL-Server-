import java.sql.*;
import javax.swing.JOptionPane;
public class Db_connect {
    Connection con;
    Statement st;
    public static void main(String[] args) {
       
    }
    public Db_connect(){
        try
        {
           Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           String url = "jdbc:sqlserver://LAB8-11\\SQL2012ENT;databaseName=Multi_Star_Restaurant;integratedSecurity=true;";
           con = DriverManager.getConnection(url, "sa", "sa9");
           st = con.createStatement();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
    }
    int id;
    
    public int getid(){
        String q = "select top 1 C_ID from Customer order by C_ID desc";
        try {
           ResultSet rs = st.executeQuery(q);
            while (rs.next()) {                
                id = rs.getInt("C_ID");
            }
        } catch (Exception e) {
        }
        return id;
        
    }
    
}
    